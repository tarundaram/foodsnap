import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab2ang',
  templateUrl: './lab2ang.component.html',
  styleUrls: ['./lab2ang.component.css']
})
export class Lab2angComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
