package com.cpg.lab9.q2;

public class Employee {

	int id;
	String name;
	double Salary;
	String designation;
	String InsuranceScheme;
	public Employee() {
		super();
		this.id = 0;
		this.name = null;
		Salary = 0.0;
		this.designation = null;
		InsuranceScheme = null;
	}
	public Employee(int id, String name, double salary, String designation, String insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		try{
			if(salary<3000){
				throw new Insuffecientsal();
			}else{
				this.Salary = salary;
			}
		}catch(Insuffecientsal e){
			e.printStackTrace();
		}
		
		this.designation = designation;
		InsuranceScheme = insuranceScheme;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		
		Salary = salary;
	}
	public String getDesignation() {
		
		return designation;
	}
	public void setDesignation(String designation) {
		double sal=this.getSalary();
		if(sal>5000 && sal<20000){
			this.designation="System Associate";
		}else if(sal>=20000 && sal<40000){
			this.designation="Programmer";
		}else if (sal>=40000){
			this.designation="Manager";
		}else{
			this.designation="Clerk";
			
		}
		
	}
	public String getInsuranceScheme() {
		
		
		return InsuranceScheme;
	}
	public void setInsuranceScheme() {
		String desg =this.getDesignation();
		if(designation=="System Associate"){
			this.InsuranceScheme="Scheme C";
		}else if(designation =="Programmer"){
			this.InsuranceScheme="Scheme B";
		}else if(designation == "Manager"){
			this.InsuranceScheme="Scheme A";
		}else{
			this.InsuranceScheme="No Scheme";
		}
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", Salary=" + Salary + ", designation=" + designation
				+ ", InsuranceScheme=" + InsuranceScheme + "]";
	}


}
