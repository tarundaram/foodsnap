package com.cg.project11.exception;

public class InvalidPhoneNoException extends Exception {

	public InvalidPhoneNoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidPhoneNoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
