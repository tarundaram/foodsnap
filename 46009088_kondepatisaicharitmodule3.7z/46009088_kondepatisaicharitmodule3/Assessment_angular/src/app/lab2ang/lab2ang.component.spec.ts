import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2angComponent } from './lab2ang.component';

describe('Lab2angComponent', () => {
  let component: Lab2angComponent;
  let fixture: ComponentFixture<Lab2angComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2angComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2angComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
