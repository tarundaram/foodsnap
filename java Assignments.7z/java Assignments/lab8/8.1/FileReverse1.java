package com.cg.lab8;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileReverse1 {

	public static void main(String[] args) {

		try {
			File file = new File("temp.txt");
			System.out.println(file.exists());
			StringBuilder data = new StringBuilder("");
			BufferedReader br = new BufferedReader(new FileReader(file));
			int j = 0;
			for (int i = 0; i < file.length(); i++) {
				j = br.read();
				data.append((char) j);
			}
			System.out.println(data);
			data.reverse();
			System.out.println(data);
			BufferedWriter fw = new BufferedWriter(new FileWriter(file));
			for (int i = 0; i < data.length(); i++) {
				j = data.charAt(i);
				fw.write((char) j);
				fw.flush();
			}

		} catch (FileNotFoundException e) {
			System.out.println("file not found");
		} catch (IOException e) {
			System.out.println("IO exception");
		}

//		File f1 = new File("C:/Users/YSALVE/Desktop/temp.txt");
//		String str = "konnnichiwa , ohaio gosaimasu";
//		byte[] b1;
//		try {
//			Scanner sc = new Scanner(System.in);
//			String in = sc.nextLine().replace(" ", "");
//			FileOutputStream fin = new FileOutputStream(f1, true);
//			BufferedOutputStream bfin = new BufferedOutputStream(fin);
//			bfin.write(in.getBytes());
//			bfin.flush();
//			bfin.close();
//
//			int i = 0;
//			FileInputStream fout = new FileInputStream(f1);
//			BufferedInputStream bfout = new BufferedInputStream(fout);
//			int j = 0;
//			char[] out = new char[100];
//			while ((i = bfout.read()) != -1) {
//				out[j] = ((char) i);
//				j++;
//			}
//			for (int k = out.length; k >= 0; k--) {
//				System.out.println(out[k]);
//			}
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
	}

}
