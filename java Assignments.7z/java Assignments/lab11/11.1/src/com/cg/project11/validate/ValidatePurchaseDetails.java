package com.cg.project11.validate;

import java.sql.Date;
import java.util.regex.Pattern;

public class ValidatePurchaseDetails {
	boolean val = false;

	public boolean isPurchaseId(String purchaseId) {
		return true;
	}

	public boolean isCustName(String custName) {
		val = false;
		if (custName.length() <= 20) {
			if (Character.isUpperCase(custName.charAt(0))) {
				val = true;
			}
		}

		return val;
	}

	public boolean isMailId(String mailId) {
		val = false;
		if (Pattern.compile("^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$").matcher(mailId).matches()) {
			val = true;
		}
		return val;
	}

	public boolean isPhoneNo(String phoneNo) {
		val = false;
		if(Pattern.compile("[0-9]{10}").matcher(phoneNo).matches())
		{
			val = true;
		}
		return val;
	}

	public boolean isPerchaseDate(Date perchaseDate) {
		return true;
	}

	public boolean isMobId(String mobId) {
		val = false;
		if(Pattern.compile("[0-9]{4}").matcher(String.valueOf(mobId)).matches())
		{
			val = true;
		}
		return val;
	}

}
