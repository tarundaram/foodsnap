package com.lab10_1;

import java.io.FileInputStream;
import java.util.Properties;

public class LoadPropertiesGet {

	public static void main(String[] args) {
		FileInputStream fin = null;
		try {
			fin = new FileInputStream("Details.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}

		Properties prop = new Properties();
		try {

			// load the properties file
			prop.load(fin);

			// print the details by using getProperties
			System.out.println(prop.getProperty("First_Name"));
			System.out.println(prop.getProperty("Last_Name"));
			System.out.println(prop.getProperty("Emp_Id"));
			System.out.println(prop.getProperty("Location"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
