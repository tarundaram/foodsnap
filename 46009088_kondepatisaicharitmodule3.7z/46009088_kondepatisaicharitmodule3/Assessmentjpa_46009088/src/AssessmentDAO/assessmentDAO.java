package AssessmentDAO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.AssessmentPOJO;

public class assessmentDAO {
   public static void main( String[ ] args ) {
   
      EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Eclipselink_JPA" );
      
      EntityManager entitymanager = emfactory.createEntityManager( );
      entitymanager.getTransaction( ).begin( );

      AssessmentPOJO asobj = new AssessmentPOJO(); 
      asobj.setEmpID(46009088);
      asobj.setMod1("webbasics");
      asobj.setMod2("java");
      asobj.setMod3("jpa");
      asobj.setMod4("plp");
      entitymanager.persist( asobj);
      entitymanager.getTransaction( ).commit( );
      entitymanager.close( );
      emfactory.close( );
   }
}

