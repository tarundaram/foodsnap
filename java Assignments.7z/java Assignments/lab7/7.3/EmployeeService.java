package com.cg.lab7_3;

import java.util.HashMap;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public abstract void displayEmployeeBasedInsurence(String insurence,HashMap<String, Employee> list);

	public abstract boolean deleteEmployee(int id,HashMap<String, Employee> list);

	public abstract void sortOnSalary(HashMap<String, Employee> list);

}
