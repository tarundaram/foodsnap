import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjcompComponent } from './projcomp.component';

describe('ProjcompComponent', () => {
  let component: ProjcompComponent;
  let fixture: ComponentFixture<ProjcompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjcompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
