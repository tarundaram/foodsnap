package com.cg.bean;

public class BusinessInfo {
private String businessId;
private String businessName;
public BusinessInfo(String businessId, String businessName) {
	super();
	this.businessId = businessId;
	this.businessName = businessName;
}
public BusinessInfo() {
	super();
}
public String getBusinessId() {
	return businessId;
}
public void setBusinessId(String businessId) {
	this.businessId = businessId;
}
public String getBusinessName() {
	return businessName;
}
public void setBusinessName(String businessName) {
	this.businessName = businessName;
}

}
