package com.cg.lab8.p8_3;

import java.util.HashMap;

import lab5.com.cg.eis.bean.Employee;

public interface EmployeeService {

	public abstract void displayEmployeeBasedInsurence(String insurence,HashMap<String, Employee> list);

	public abstract boolean deleteEmployee(int id,HashMap<String, Employee> list);

	public abstract void sortOnSalary(HashMap<String, Employee> list);
	
	public abstract void printToFile(HashMap<String, Employee> list);

}
