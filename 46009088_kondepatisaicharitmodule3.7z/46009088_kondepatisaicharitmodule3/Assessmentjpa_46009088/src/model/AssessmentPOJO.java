package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AssessmentPOJO {
@Id
@GeneratedValue(strategy = GenerationType.AUTO) 	

private long EmpID;
@Column
private String mod1;
@Column
private String mod2;
@Column
private String mod3;
@Column
private String mod4;
public AssessmentPOJO(long empID, String mod1, String mod2, String mod3, String mod4) {
	super();
	EmpID = empID;
	this.mod1 = mod1;
	this.mod2 = mod2;
	this.mod3 = mod3;
	this.mod4 = mod4;
}

public AssessmentPOJO() {
	super();
}

public long getEmpID() {
	return EmpID;
}
public void setEmpID(long empID) {
	EmpID = empID;
}
public String getMod1() {
	return mod1;
}
public void setMod1(String mod1) {
	this.mod1 = mod1;
}
public String getMod2() {
	return mod2;
}
public void setMod2(String mod2) {
	this.mod2 = mod2;
}
public String getMod3() {
	return mod3;
}
public void setMod3(String mod3) {
	this.mod3 = mod3;
}
public String getMod4() {
	return mod4;
}
public void setMod4(String mod4) {
	this.mod4 = mod4;
}
@Override
public String toString() {
	return "AssessmentPOJO [EmpID=" + EmpID + ", mod1=" + mod1 + ", mod2=" + mod2 + ", mod3=" + mod3 + ", mod4=" + mod4
			+ "]";
}
}
