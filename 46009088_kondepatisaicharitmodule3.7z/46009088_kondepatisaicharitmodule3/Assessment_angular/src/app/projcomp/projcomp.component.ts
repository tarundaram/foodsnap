import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projcomp',
  templateUrl: './projcomp.component.html',
  styleUrls: ['./projcomp.component.css']
})
export class ProjcompComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }
Empid=46009088;
mod1name:string;
mod2name:string;
mod3name:string;
mod4name:string;

val(){
 
  
}
}

