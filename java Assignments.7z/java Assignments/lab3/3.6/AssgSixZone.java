package com.cg.lab3;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;
public class AssgSixZone {

	public static ZonedDateTime getZone(String str)
	{
		ZonedDateTime zoneinfo = ZonedDateTime.now(ZoneId.of(str));
		return zoneinfo;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a time zone name -> ");
		
		System.out.println("Current Date and Time of this Zone is -> "+getZone(sc.next()));
		sc.close();
	}

}
