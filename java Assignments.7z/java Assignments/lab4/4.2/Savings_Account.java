package com.cg.lab4;

public class Savings_Account extends Account {

	final double minimum_balance = 500;

	public Savings_Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Savings_Account(double balance,long accNum) {
		super(balance,accNum);
		// TODO Auto-generated constructor stub
	}

	public Savings_Account(String name, Float age) {
		super(name, age);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void withdraw(double balance) {
		if (super.balance > minimum_balance && (super.balance -= balance) > minimum_balance){
			super.balance -= balance;
			System.out.println("withdrew " + balance + " from " + super.accNum);
		}else{
			System.out.println("Sorry! you don't have enough balance."+super.accNum);
		}
	}
}
// (balance -= balance) > minimum_balance