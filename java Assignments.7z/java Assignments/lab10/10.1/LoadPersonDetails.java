package com.lab10_1;

import java.io.FileInputStream;
import java.util.Properties;

public class LoadPersonDetails {
	public static void main(String[] args) {
		FileInputStream fin = null;
		try {
			fin = new FileInputStream("Details.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}

		Properties p = new Properties();
		try {
			// loading the details
			p.load(fin);

			// printing the details into the console
			System.out.println(p);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
