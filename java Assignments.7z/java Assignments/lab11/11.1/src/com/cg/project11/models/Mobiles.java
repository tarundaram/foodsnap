package com.cg.project11.models;

public class Mobiles {
	private String mobileId;
	private String mobName;
	private String price;
	private String quantity;
	public Mobiles() {
		super();
		this.mobileId = "";
		
		this.mobName = "";
		this.price = "";
		this.quantity = "";
	}
	public Mobiles(String mobileId, String mobName, String price, String quantity) {
		super();
		this.mobileId = mobileId;
		this.mobName = mobName;
		this.price = price;
		this.quantity = quantity;
	}
	public String getMobileId() {
		return mobileId;
	}
	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", mobName=" + mobName + ", price=" + price + ", quantity=" + quantity
				+ "]";
	}
	
	
}
