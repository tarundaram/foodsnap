package com.cg.project11.view;

import java.util.Scanner;

import com.cg.project11.doa.MobilePurchaseDOA;
import com.cg.project11.models.PurchaseDetails;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		MobilePurchaseDOA mpd = new MobilePurchaseDOA();
		GetInputForPurchase gi = new GetInputForPurchase();
		PurchaseDetails pd = new PurchaseDetails("Faiz", "faiz@gmail.com", "9807465372", "1006");
		Scanner sc = new Scanner(System.in);
		mpd.getPurchaseId();
		// mpd.addPerchaseRec(pd);
		// mpd.quantityCheck(1004);
		while (true) {
			System.out.println(
					"\n 1. Mobiles \n 2. Search Mobiles \n 3. Delete Record of Mobile \n 4. Enter Purchase Details \n 5. Exit \n\n");
			System.out.println("Select One Menu to Continue.. ");
			int i = sc.nextInt();
			switch (i) {
			case 1:
				mpd.showMobiles();
				break;
			case 2:
				System.out.println("Enter lower limit for searching..");
				double lower = sc.nextDouble();
				System.out.println("Enter higher limit for searching..");
				double higher = sc.nextDouble();
				mpd.searchOnPrice(lower, higher);
				break;
			case 3:
				System.out.println("Enter mobile id to delete record..");
				int id = sc.nextInt();
				mpd.deleteMobile(id);
				break;
			case 4:
				System.out.println("Enter number of record to enter...");
				int recno = sc.nextInt();
				int k = 1;
				while (recno > 0) {
					System.out.println("Enter record "+k++ );
					System.out.println("Enter no of items to purchase...");
					int no = sc.nextInt();
					String a = gi.getMobId();
					String b = gi.getCustName();
					String c = gi.getMailId();
					String d = gi.getPhoneNo();
					pd.setMobId(a);
					pd.setCustName(b);
					pd.setMailId(c);
					pd.setMobId(d);
					mpd.addPerchaseRec(pd, no);
					--recno;
				}
				break;
			case 5:
				System.out.println("Thanks for the Visit !!");
				return;
			case 6:
				return;
			default:
				System.out.println("Please select options from the list..");
				break;
			}
		}

		// mpd.getCon();

		// System.out.println();

	}

}
