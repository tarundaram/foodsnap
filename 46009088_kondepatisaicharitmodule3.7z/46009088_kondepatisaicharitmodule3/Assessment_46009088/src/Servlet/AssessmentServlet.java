package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AssessmentServlet
 */
@WebServlet("/AssessmentServlet")
public class AssessmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssessmentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int mod1 = Integer.parseInt(request.getParameter("mod1"));
		int mod2 = Integer.parseInt(request.getParameter("mod2"));
		int mod3 = Integer.parseInt(request.getParameter("mod3"));
		int mod4 = Integer.parseInt(request.getParameter("mod4"));
		int avg;
		avg= (mod1+mod2+mod3+mod4)/4;
		if(avg>=60){
			response.sendRedirect("Success.jsp");
		}
		else{
			response.sendRedirect("Failure.jsp");
		}
	}

}
