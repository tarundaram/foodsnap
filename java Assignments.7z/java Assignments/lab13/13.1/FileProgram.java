package com.cg.lab13;

//import com.cg.threads.MyThread;

public class FileProgram {

	public static void main(String[] args) {
		CopyDataThread cdt = new CopyDataThread();
		cdt.start();
		

	}

}
