package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bean.Claim;
import com.cg.bean.ClaimDetails;
import com.cg.bean.Questions;
import com.cg.bean.UserRole;
import com.cg.utility.ConnectDB;

public class PolicyClaimDao implements IPolicyClaimDao {
	
	ConnectDB db;
	Connection con;

	public PolicyClaimDao() {
		 db=new ConnectDB();
		 try{
		 con=db.getConnection();
		 }catch(Exception e){
			 
		 }
	}

	@Override
	public String validate(String userName, String password)  {
		String roleCode=null;
		try {
			
		 
		String qry="select rolecode from userrole where userName=? and password=?";
		
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setString(1,userName);
		pstmt.setString(2, password);
		ResultSet rs=pstmt.executeQuery();
		//pstmt.executeUpdate();
		rs.next();
		 roleCode=rs.getString(1);
		
		}catch(Exception e) {
			
		}
		return roleCode;
	}

	@Override
	public List<String> viewPolicy(String userName,String roleCode) {
		String qry;
		int accountNumber=0;
		int policyNumber;
		double premium;
		String data;
		List<String> list=new ArrayList<String>();
		try {
		PreparedStatement pstmt=null;
		//System.out.println(userName+"dao");
		//System.out.println(roleCode);
		if(roleCode.equals("admin")) {
			//System.out.println(userName+"dao");
			//System.out.println(roleCode);
			 qry="select pd.accountnumber,pd.policynumber,p.policypremium from policy p,policydetails pd where p.policynumber=pd.policynumber";
					
			 pstmt=con.prepareStatement(qry);
			 
		}
		if(roleCode.equals("insured") || roleCode.equals("agent")) {
			qry="select a.accountnumber,pd.policynumber,p.policypremium from accounts a,policydetails pd,policy p where a.username=? and a.accountnumber=pd.accountnumber and pd.policynumber=p.policynumber";
					
			 pstmt=con.prepareStatement(qry);
			 pstmt.setString(1, userName);
		}
		
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()) {
			 accountNumber=rst.getInt(1);
			 policyNumber=rst.getInt(2);
			 premium=rst.getDouble(3);
			 
			 data=accountNumber+":"+policyNumber+":"+premium;
			 list.add(data);
			}
		
		}catch(Exception e) {
			
		}
		
		return list;
		
	}

	@Override
	public List<String> viewClaimStatus(String userName,String roleCode) {
		String qry=null;
		PreparedStatement pstmt=null;
		ArrayList<String> list=new ArrayList<String>();
		System.out.println(userName);//////////
		
		try{
		
		if(roleCode.equals("admin")){
			qry="select pd.accountnumber,pd.policynumber,c.claimnumber from policydetails pd,claimcreation c where pd.policynumber=c.policynumber";
					
			      pstmt=con.prepareStatement(qry);
		}
		if(roleCode.equals("insured") || roleCode.equals("agent")){
			qry="select pd.accountnumber,pd.policynumber,c.claimnumber from accounts a,policydetails pd,claimcreation c where a.username=? and a.accountnumber=pd.accountnumber and pd.policynumber=c.policynumber";
					
			pstmt=con.prepareStatement(qry);
			pstmt.setString(1, userName);
		}
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()){
			int accountNumber=rst.getInt(1);
			int policyNumber=rst.getInt(2);
			int claimNumber=rst.getInt(3);
			String data=accountNumber+":"+policyNumber+":"+claimNumber;
			list.add(data);
		}
		
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public Map<Claim,ClaimDetails> viewClaimDetail(int claimNumber) {
		Map<Claim,ClaimDetails> map=new HashMap<Claim,ClaimDetails>();
		String qry1="select * from claimcreation where claimNumber=?";
		String qry2="select * from claimdetails where claimNumber=?";
		try {
		PreparedStatement pstmt1=con.prepareStatement(qry1);
		PreparedStatement pstmt2=con.prepareStatement(qry2);
		pstmt1.setInt(1,claimNumber);
		pstmt2.setInt(1, claimNumber);
		ResultSet rst1=pstmt1.executeQuery();
		Claim claim=new Claim();
		while(rst1.next()) {
			claim.setClaimNumber(claimNumber);
			claim.setClaimReason(rst1.getString(2));
			claim.setAccidentLocation(rst1.getString(3));
			claim.setAccidentCity(rst1.getString(4));
			claim.setAccidentState(rst1.getString(5));
			claim.setAccidentZip(rst1.getInt(6));
			claim.setClaimType(rst1.getString(7));
			claim.setPolicyNumber(rst1.getInt(8));
			
		}
		ResultSet rst2=pstmt2.executeQuery();
		ClaimDetails claimdetails=new ClaimDetails();
		while(rst2.next()) {
			claimdetails.setClaimNumber(claimNumber);
			claimdetails.setQuestion1(rst2.getString(2));
			claimdetails.setQuestion2(rst2.getString(3));
			claimdetails.setQuestion3(rst2.getString(4));
			claimdetails.setQuestion4(rst2.getString(5));
			claimdetails.setQuestion5(rst2.getString(6));
			claimdetails.setAnswer1(rst2.getString(7));
			claimdetails.setAnswer2(rst2.getString(8));
			claimdetails.setAnswer3(rst2.getString(9));
			claimdetails.setAnswer4(rst2.getString(10));
			claimdetails.setAnswer5(rst2.getString(11));
			
			
		}
		map.put(claim, claimdetails);
		}catch(Exception e) {
			
		}
		return map;
	}

	

	@Override
	public boolean createUser(UserRole user) {
		boolean flag = true;
		try {
		
			Connection con=db.getConnection();
			String username=user.getUserName();
			String password=user.getPassword();
			String rolecode=user.getRoleCode();
			String qry1="select username,password from userrole where username=?";
			PreparedStatement pstmt=con.prepareStatement(qry1);
			pstmt.setString(1,username);
			//pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				 flag=false;	
			}
			else
			{
				
				String q2="insert into userrole values(?,?,?)";
				PreparedStatement pstmt1=con.prepareStatement(q2);
				pstmt1.setString(1,username);
				pstmt1.setString(2, password);
				pstmt1.setString(3, rolecode);
				pstmt1.executeUpdate();
				con.commit();
				  flag=true;
			}
			
		
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
		
	}

	@Override
	public List<String> generateReport() {
		List<String> list=new ArrayList<String>();
		String qry="select pd.accountnumber,c.claimnumber,c.policynumber,c.claimtype from policydetails pd,claimcreation c where pd.policynumber=c.policynumber";
				
		try{
		PreparedStatement pstmt=con.prepareStatement(qry);
		ResultSet rst=pstmt.executeQuery();
		while(rst.next()){
			int accountNumber=rst.getInt(1);
			int claimNumber=rst.getInt(2);
			int policyNumber=rst.getInt(3);
			String claimType=rst.getString(4);
			String data=accountNumber+":"+claimNumber+":"+policyNumber+":"+claimType;
			list.add(data);
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(list);//////////////
		return list;
	}

	

	@Override
	public int storeClaimForm(Claim claim) {//this method is used for to claim
		int claimNumber=0;
		try {
			
		
		String qry="insert into claimcreation values(claim_sequence.nextval,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(qry);
	
		pstmt.setString(1, claim.getClaimReason());
		pstmt.setString(2, claim.getAccidentLocation());
		pstmt.setString(3, claim.getAccidentCity());
		pstmt.setString(4, claim.getAccidentState());
		pstmt.setInt(5,claim.getAccidentZip());
		pstmt.setString(6,claim.getClaimType());
		pstmt.setInt(7,claim.getPolicyNumber());
		
		pstmt.executeUpdate();
		
		
		String qry1="select claim_sequence.currval from DUAL";
		pstmt=con.prepareStatement(qry1);
		ResultSet rst=pstmt.executeQuery();
		// System.out.println(claimNumber);///////////////////////////
		rst.next();
		 claimNumber=rst.getInt(1);
		 
		 //System.out.println(claimNumber);//////////////////
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return claimNumber;
	}

	@Override
	public Questions getQuestions(int policyNumber) {//this method is used for to claim
		Questions questions=new Questions();
		try {
		String qry="select businessId from policydetails where policyNumber=?";
		PreparedStatement pstmt=con.prepareStatement(qry);
		pstmt.setInt(1,policyNumber);
		ResultSet rst=pstmt.executeQuery();
		rst.next();
		int businessId=rst.getInt(1);
		
		
		qry="select * from questions where businessId=?";
		pstmt=con.prepareStatement(qry);
		pstmt.setInt(1, businessId);
		 rst=pstmt.executeQuery();
		 rst.next();
		 questions.setQuestion1(rst.getString(2));
		 questions.setQuestion2(rst.getString(3));
		 questions.setQuestion3(rst.getString(4));
		 questions.setQuestion4(rst.getString(5));
		 questions.setQuestion5(rst.getString(6));
		 questions.setAnswer1(rst.getString(7));
		 questions.setAnswer2(rst.getString(8));
		 questions.setAnswer3(rst.getString(9));
		 questions.setAnswer4(rst.getString(10));
		 questions.setAnswer5(rst.getString(11));
		}catch(Exception e) {
			
		}
		 
		 
	 	return questions;
	}

	@Override
	public void storeAnswers(ClaimDetails myAnswers) {//this method is used for to claim
		String qry="insert into claimdetails values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
		PreparedStatement pstmt=con.prepareStatement(qry);
		System.out.println(myAnswers.getQuestion1());
		pstmt.setInt(1, myAnswers.getClaimNumber());
		pstmt.setString(2,myAnswers.getQuestion1());
		pstmt.setString(3,myAnswers.getQuestion2());
		pstmt.setString(4,myAnswers.getQuestion3());
		pstmt.setString(5,myAnswers.getQuestion4());
		pstmt.setString(6,myAnswers.getQuestion5());
		pstmt.setString(7, myAnswers.getAnswer1());
		pstmt.setString(8, myAnswers.getAnswer2());
		pstmt.setString(9, myAnswers.getAnswer3());
		pstmt.setString(10, myAnswers.getAnswer4());
		pstmt.setString(11, myAnswers.getAnswer5());
		
		pstmt.executeUpdate();
		}catch(Exception e) {
			
		}
		
		
	}

}
