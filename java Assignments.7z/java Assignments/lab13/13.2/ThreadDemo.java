package com.cg.lab13_2;

import java.time.LocalTime;

public class ThreadDemo implements Runnable {

	public void getTime() {
		try {
			while (true) {
				System.out.println("Current Time :" + LocalTime.now());
				Thread.sleep(10000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		getTime();

	}

}
