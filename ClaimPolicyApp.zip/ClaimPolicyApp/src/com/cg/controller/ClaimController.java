package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Claim;
import com.cg.bean.ClaimDetails;
import com.cg.bean.Questions;
import com.cg.bean.UserRole;
import com.cg.service.PolicyClaimService;

/**
 * Servlet implementation class ClaimController
 */
@WebServlet("*.obj")
public class ClaimController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public ClaimController() {
        super();  
    }
    PolicyClaimService service=new PolicyClaimService();
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath().trim();
		String resource=null;
		String userName;
		String password;
		int claimNumber;
		String roleCode=null;
		int policyNumber;
		
		switch(path){
				
		case "/login.obj":
			 userName=request.getParameter("username");
			 password=request.getParameter("password");
			 roleCode=service.validate(userName,password);
			String message=null;
			if(roleCode==null){
				resource="login.jsp";
				message="Username or passowrd is incorrect!";
				request.setAttribute("message", message);
			}
			if(roleCode.equals("admin")){
				request.setAttribute("username",userName);
				request.setAttribute("roleCode", roleCode);
				//System.out.println(userName);
				//System.out.println(roleCode);
				resource="admin.jsp";
			}
			if(roleCode.equals("insured")){
				request.setAttribute("username",userName);
				request.setAttribute("roleCode", roleCode);
				resource="insured.jsp";
			}
			if(roleCode.equals("agent")){
				request.setAttribute("username",userName);
				request.setAttribute("roleCode", roleCode);
				resource="agent.jsp";
			}
			
			break;
			
		case "/view.obj":
			String value=request.getParameter("name1");
			if(value.equals("viewPolicy")){
				userName=(String)request.getParameter("username");
				roleCode=(String)request.getParameter("roleCode");
				
				List<String> data=service.viewPolicy(userName,roleCode);//List contains accountNo.:policyNumber:premium
				request.setAttribute("policyList", data);
				request.setAttribute("username",userName);
				resource="policyList.jsp";
			}
			if(value.equals("viewClaimStatus")){
				userName=(String)request.getParameter("username");
				roleCode=(String)request.getParameter("roleCode");
				List<String> claimStatus=service.viewClaimStatus(userName,roleCode);//accountNumber+":"+policyNumber+":"+claimNumber
				request.setAttribute("claimStatus", claimStatus);
				resource="claimStatusList.jsp";
			}
			if(value.equals("viewReportGeneration")){
					List<String> reportList=service.generateReport();
					request.setAttribute("reportList", reportList);
					System.out.println(reportList);///////////////////
					resource="reportGenerationList.jsp";
			}
			break;
		case "/createUser.obj":
			 userName=request.getParameter("username");
		     password=request.getParameter("password");
			 roleCode=request.getParameter("rolecode");
			UserRole user=new UserRole(userName,password,roleCode);
			boolean status=service.createUser(user);
			if(status){
			resource="success.jsp";
			message="Congrats!User successfully created.";
			request.setAttribute("message", message);
			}
			break;
			
	
		case "/viewDetail.obj"://this will be used by view button
			claimNumber=Integer.parseInt(request.getParameter("claimNumber"));
			Map<Claim,ClaimDetails> questionAnswer=service.viewClaimDetail(claimNumber);
			request.setAttribute("questionAnswer",questionAnswer);
			resource="claimDetailPage.jsp";
			break;
			
		case "/claimForm.obj":
			String claimReason=request.getParameter("claimreason");
			String accidentLocation=request.getParameter("accidentlocation");
			String accidentCity=request.getParameter("accidentcity");
			String accidentState=request.getParameter("accidentstate");
			int accidentZip=Integer.parseInt(request.getParameter("accidentzip"));
			String claimType=request.getParameter("claimtype");
			 policyNumber=Integer.parseInt(request.getParameter("policynumber"));
			 
			 
			 
			 Claim claim=new Claim(0,claimReason,accidentLocation,accidentCity,accidentState,accidentZip,claimType,policyNumber);
			 
			 claimNumber=service.storeClaimForm(claim);
			 
			 
			 request.setAttribute("claimNumber",claimNumber);
			 Questions questions=service.getQuestions(policyNumber);     
			 request.setAttribute("questions", questions);
			 resource="claimQuestionsPage.jsp";
			 break;
			 
		case "/claimQuestion.obj":
			String a1=(String)request.getParameter("q1");
			String a2=(String)request.getParameter("q2");
			String a3=(String)request.getParameter("q3");
			String a4=(String)request.getParameter("q4");
			String a5=(String)request.getParameter("q5");
			
			//System.out.println(a5);
			String  qns=request.getParameter("questionString");
			//System.out.println(qns);
			String [] questionArr=qns.split(":");
			
			claimNumber=Integer.parseInt(request.getParameter("claimNumber"));
			
			//System.out.println(claimNumber);
			//System.out.println(questionArr[0]);////////
			
			ClaimDetails myAnswers=new ClaimDetails(claimNumber,questionArr[0],questionArr[1],questionArr[2]
					,questionArr[3],questionArr[4],a1,a2,a3,a4,a5);
			 service.storeAnswers(myAnswers);
			 request.setAttribute("claimNumber", claimNumber);
			 resource="success.jsp";
			 break;
			 
		}
		RequestDispatcher rd=request.getRequestDispatcher(resource);
		rd.forward(request,response);
			
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
