package com.lab10_1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class StorePersonDetails {
	public static void main(String[] args) {
		OutputStream out = null;
		try {
			out = new FileOutputStream("Details.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}

		// creating properties
		Properties p = new Properties();

		// set the properties values
		p.setProperty("First_Name", "Michael");
		p.setProperty("Last_Name", "Jordan");
		p.setProperty("Emp_Id", "460000");
		p.setProperty("Location", "Pakistan, Karachi.");

		// save the properties to the root folder
		try {
			p.store(out, "Storing the Person Details");
			// System.out.println(p);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
