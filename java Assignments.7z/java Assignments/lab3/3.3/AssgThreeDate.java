package com.cg.lab3;

import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class AssgThreeDate {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a date to get duration -> [dd-MM-yyyy]");
		String str = sc.next();
		DateTimeFormatter fr = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate dl = LocalDate.parse(str,fr);
		LocalDate dle = LocalDate.now();

		Period period = dl.until(dle);

		System.out.println("Duration is -> ");
		System.out.println( period.getYears()+" Years , " + period.getMonths()+ " Months , "+ period.getDays()+ " days . ");
		sc.close();
		
	}

}
