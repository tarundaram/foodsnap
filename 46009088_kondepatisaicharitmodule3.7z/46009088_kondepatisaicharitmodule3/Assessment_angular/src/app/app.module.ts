import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ProjcompComponent } from './projcomp/projcomp.component';
import { Lab2angComponent } from './lab2ang/lab2ang.component';

@NgModule({
  declarations: [
    AppComponent,
    ProjcompComponent,
    Lab2angComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]

})
export class AppModule { }


