//  Lab 2 - Assignment 2.2 Program for getting argument from command line and finding negative or positive .

package com.cg.lab2;

public class CommLineArg {

	public static void main(String[] args) {
		
		String b = args[0];
		int a = Integer.parseInt(b);
		if(a > 0)
		{
			System.out.println("Entered Number Is "+ a + " And Positive");
		}
		else
		{
			System.out.println("Entered Number Is "+ a + " And Negative");
		}
	

	}

}
