package com.cg.bean;

public class Policy {
	private int policyNumber;
	private double policyPremium;
	
	public Policy() {
		super();
	}
	public Policy(int policyNumber, int policyPremium) {
		
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
	}
	public int getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}
	public double getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(int policyPremium) {
		this.policyPremium = policyPremium;
	}
	
	

}
